# 👟 STRIDE - Catálogo de Tenis

Página web moderna y responsive para catálogo de tenis deportivos y urbanos.

## 🚀 Características

- ✨ Diseño moderno y atractivo
- 📱 Totalmente responsive (móvil, tablet, desktop)
- 🎨 Animaciones suaves y efectos hover
- 🔍 Sistema de filtros por categorías
- ⚡ Rendimiento optimizado

## 🛠️ Tecnologías

- HTML5
- CSS3 (Grid, Flexbox, Animaciones)
- JavaScript (Vanilla)
- Google Fonts (Bebas Neue, Outfit)

## 📁 Estructura del Proyecto

```
catalogo-tenis/
│
├── index.html          # Página principal
├── styles.css          # Estilos CSS
├── script.js           # Funcionalidad JavaScript
└── README.md           # Este archivo
```

## 🎯 Uso

1. **Clonar el repositorio:**
```bash
git clone https://github.com/tu-usuario/catalogo-tenis.git
```

2. **Abrir en el navegador:**
Simplemente abre el archivo `index.html` en tu navegador favorito.

## 🌐 GitHub Pages

Para publicar tu sitio en GitHub Pages:

1. Ve a tu repositorio en GitHub
2. Haz clic en **Settings**
3. Navega a **Pages** en el menú lateral
4. En **Source**, selecciona la rama `main` y la carpeta `/root`
5. Haz clic en **Save**
6. Tu sitio estará disponible en: `https://tu-usuario.github.io/catalogo-tenis/`

## 🎨 Personalización

### Colores
Los colores principales se pueden modificar en `styles.css`:

```css
:root {
    --primary: #FF4D00;    /* Naranja principal */
    --secondary: #0D0D0D;  /* Negro */
    --accent: #FFE600;     /* Amarillo */
    --light: #F5F5F5;      /* Gris claro */
}
```

### Productos
Para agregar nuevos productos, edita el HTML en `index.html` dentro de la sección `.product-grid`:

```html
<div class="product-card" data-category="running">
    <div class="product-tag">NUEVO</div>
    <div class="product-image">
        <div class="img-placeholder">👟</div>
    </div>
    <div class="product-info">
        <div class="product-category">Running</div>
        <h3 class="product-name">Nombre del Producto</h3>
        <p class="product-description">Descripción del producto...</p>
        <div class="product-footer">
            <div class="product-price"><span>$</span>999</div>
            <button class="buy-btn">Comprar</button>
        </div>
    </div>
</div>
```

### Imágenes
Reemplaza los emojis en `.img-placeholder` con imágenes reales:

```html
<!-- Cambiar esto: -->
<div class="img-placeholder">👟</div>

<!-- Por esto: -->
<img src="ruta/a/tu/imagen.jpg" alt="Nombre del producto">
```

## 📋 Categorías Disponibles

- `running` - Tenis para correr
- `basketball` - Tenis de basketball
- `casual` - Tenis casuales
- `training` - Tenis de entrenamiento

## 🤝 Contribuir

¡Las contribuciones son bienvenidas! Si deseas mejorar este proyecto:

1. Haz un Fork del proyecto
2. Crea una rama para tu función (`git checkout -b feature/NuevaCaracteristica`)
3. Commit tus cambios (`git commit -m 'Agregar nueva característica'`)
4. Push a la rama (`git push origin feature/NuevaCaracteristica`)
5. Abre un Pull Request

## 📝 Licencia

Este proyecto es de código abierto y está disponible bajo la Licencia MIT.

## ✨ Autor

Creado con 💙 para la comunidad de desarrolladores

---

**¡Dale una ⭐ si te gustó este proyecto!**
